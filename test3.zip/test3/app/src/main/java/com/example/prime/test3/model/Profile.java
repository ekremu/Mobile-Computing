//Das Modell enthält Daten, die von der Präsentation dargestellt werden. Es ist von Präsentation
// und Steuerung unabhängig. Die Änderungen der Daten werden der Präsentation durch das Entwurfsmuster
// „Beobachter“ bekanntgegeben. In manchen Umsetzungen des MVC-Musters enthält das Modell eine Geschäftslogik,
// die für die Änderung der Daten zuständig ist.
package com.example.prime.test3.model;

import android.view.View;

import androidx.annotation.Nullable;

import java.util.Objects;



public class Profile {

/*
    private View nickname;
     private View email;
    private View password;
    private View stadt;
    private View score ;

 */


    private String nickname;
    private String email;
    private String password;
    private String stadt;
    private int score ;



    public Profile(String nickname, String email, String password, String stadt, int score){

        this.nickname = nickname;
        this.email = email;
        this.password = password;
        this.stadt = stadt;
        this.score = score;

    }



    public void setStadt(String stadt) {
        this.stadt = stadt;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getStadt() {
        return stadt;
    }

    public int getScore() {
        return score;
    }


/*
    public void setStadt(View stadt) {
            this.stadt = stadt;
        }

        public void setScore(View score) {
           this.score = score;
        }

        public void setNickname(View nickname) {
            this.nickname = nickname;
       }

        public void setEmail(View email) {
            this.email = email;
        }

        public void setPassword(View password) {
            this.password = password;
        }

        public View getNickname() {
            return nickname;
      }

        public View getEmail() {
            return email;
        }

        public View getPassword() {
            return password;
        }

        public View getStadt() {
            return stadt;
        }

        public View getScore() {
           return score;
        }


 */

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        return super.equals(obj);
    }
}
