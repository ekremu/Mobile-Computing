package com.example.prime.test3;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

import com.example.prime.test3.viewmodel.ProfileViewModel;





public class ProfileActivity extends AppCompatActivity {

    private ProfileViewModel viewModel;

    //TextView nick = findViewById(R.id.txt_userprofile);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        viewModel = ViewModelProviders.of(this).get(ProfileViewModel.class);

        //String data = getIntent().getExtras().getString("name","name");
        //nick.setText(data);



    }





}
