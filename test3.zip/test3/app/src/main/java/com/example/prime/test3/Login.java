package com.example.prime.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        intListeners();
    }

    public void intListeners(){

        Button btn = (Button) findViewById(R.id.btn_login);
        Button btn2 = (Button) findViewById(R.id.btn_loginsignin);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tv = new TextView(Login.this);
                final Application app = getApplication();

                Intent intent = new Intent(Login.this, Register.class);


                startActivity(intent);


            }
        });




    }
}