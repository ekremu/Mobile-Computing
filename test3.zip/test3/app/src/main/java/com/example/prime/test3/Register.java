package com.example.prime.test3;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import android.widget.Button;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.prime.test3.model.Profile;
import com.example.prime.test3.viewmodel.ProfileViewModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.w3c.dom.Text;

import java.util.List;

public class Register extends AppCompatActivity {


    private ProfileViewModel viewModel;

    ImageView img;
    static int PReqCode = 1;
    static int REQUESTCODE = 1;
    Uri pickedImgUri;
    int score = 0;


    private EditText userName, userMail, userPassword, userPassword2;
    //private ProgressBar loadingProgress;
    private Button signbtn;

    private FirebaseAuth mAuth;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        img = findViewById(R.id.img_photoAdd);
        viewModel = ViewModelProviders.of(this).get(ProfileViewModel.class);
        setupButton();

        //ini views
        userMail = findViewById(R.id.txt_email);
        userName = findViewById(R.id.txt_username);
        userPassword = findViewById(R.id.txt_password);
        userPassword2 = findViewById(R.id.txt_password2);
       // loadingProgress = findViewById(R.id.pb_register);
        signbtn = findViewById(R.id.btn_registersignin);

       // loadingProgress.setVisibility(View.INVISIBLE);

        mAuth = FirebaseAuth.getInstance();

        signbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                signbtn.setVisibility(View.INVISIBLE);
               // loadingProgress.setVisibility(View.INVISIBLE);
                final String email = userMail.getText().toString();
                final String name = userName.getText().toString();
                final String password = userPassword.getText().toString();
                final String password2 = userPassword2.getText().toString();

                if( email.isEmpty() || name.isEmpty() || password.isEmpty() || password2.isEmpty() || !password.equals(password2)){


                    showMessage("Please fill out all fields and use the same 'Confirmation password'" );
                    signbtn.setVisibility(View.VISIBLE);
                    //loadingProgress.setVisibility(View.VISIBLE);


                }

                else{

                    createUserAccount(email,name,password);
                }


            }
        });



        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT >= 22){

                    requestForPermission();

                }

                else
                {
                    openGallery();
                }




            }
        });

    }

    private void createUserAccount(String email, final String name, String password) {


            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){

                        showMessage("Account created");
                        if(findViewById(R.id.img_photoAdd).equals(findViewById(R.id.img_photoAdd))){
                            updateUserInfo(name,mAuth.getCurrentUser());
                            updateUI();
                        }
                        else{
                            updateUserInfo(name, pickedImgUri,mAuth.getCurrentUser());
                            updateUI();
                        }
                        //die if klause muss rein, falls ein Nutzer ein Profil ohne Bild erstellen möchte, damit er auch dann in die nächste Activity weitergeleitet wird



                    }

                    else {
                        showMessage("Account creation failed!" + task.getException().getMessage());
                        signbtn.setVisibility(View.VISIBLE);
                        //loadingProgress.setVisibility(View.VISIBLE);

                    }
                }
            });



    }

    private void showMessage(String message) {
        //toast = nachricht die aufpoppt und wieder weg geht
        Toast.makeText(getApplicationContext(),message,Toast.LENGTH_LONG).show();
    }

    private void updateUserInfo(final String name, Uri pickedImgUri, final FirebaseUser currentUser){

        StorageReference mStorage = FirebaseStorage.getInstance().getReference().child("user_photos");
        final StorageReference imageFilePath = mStorage.child(pickedImgUri.getLastPathSegment());
        imageFilePath.putFile(pickedImgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                //wenn image upgeloadet wird -> deshalb auch onsuccesslistener
                imageFilePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {


                        UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder().setDisplayName(name).setPhotoUri(uri).build();

                        currentUser.updateProfile(profileUpdate).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if(task.isSuccessful())
                                showMessage("Registration complete");


                            }
                        });


                    }
                });

            }
        });


    }

    private void updateUserInfo(final String name,final FirebaseUser currentUser){




                        UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder().setDisplayName(name).build();

                        currentUser.updateProfile(profileUpdate).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if(task.isSuccessful())
                                    showMessage("Registration complete");


                            }
                        });









    }

    private void updateUI() {

        Intent profileActivity = new Intent(getApplicationContext(),ProfileActivity.class);
       // profileActivity.putExtra("name", (Parcelable) userName);
        startActivity(profileActivity);
        //finish damit man nicht zur acitvity zurückkommt wenn man "back" button drückt
        finish();

    }

    @Override
    protected void onResume() {
        super.onResume();
        displayAllInformations();
    }

    private void setupButton(){
        Button buttonAdd = findViewById(R.id.btn_registersignin);
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //viewModel.addProfile(findViewById(R.id.txt_username),findViewById(R.id.txt_email),findViewById(R.id.txt_password),findViewById(R.id.txt_stadt),findViewById(R.id.txt_score));
                TextView username = findViewById(R.id.txt_username);
                TextView email = findViewById(R.id.txt_email);
                TextView password = findViewById(R.id.txt_password);
              //  TextView stadt = findViewById(R.id.txt_stadt);
             //   TextView score = findViewById(R.id.txt_score);

                String usr = username.getText().toString();
                String ema = email.getText().toString();
                String pass = password.getText().toString();
               // String sta = stadt.getText().toString();
              //  String sco = score.getText().toString();

                //score -> profil activity, wie integriert man score in die profil activity weil es nicht in die register activity gehoert, so dass der RICHTIGE Nutzer seine richtigen Score Werte bekommt



                viewModel.addProfile(usr,ema,pass);
            }
        });
    }

    private void displayAllInformations(){

                viewModel.getProfiles().observe(this, new Observer<List<Profile>>() {
            @Override
            public void onChanged(List<Profile> profiles) {
                renderAllProfiles(profiles);
            }
        });

    }

    private void renderAllProfiles(List<Profile> profiles) {
        LinearLayout container = findViewById(R.id.ll_container);
        container.removeAllViews();
        for (Profile p: profiles){
            //container.addView((View) getProfileTextView(p));
            container.addView(getProfileTextView(p));
        }

    }

    private View getProfileTextView(Profile p){

       // setScore(0);

        TextView textView = new TextView(Register.this);
        textView.setText(p.getNickname() + "(" + p.getEmail()  + ")\n");
        return textView;

    }

    public void setScore(int score) {
        this.score = score;
    }



    //image hinzufügen

    private void openGallery() {

        Intent galleryIntent  = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,REQUESTCODE);

    }

    private void requestForPermission() {

        if (ContextCompat.checkSelfPermission(Register.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(Register.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

                Toast.makeText(Register.this, "Please accept for required Permissions", Toast.LENGTH_SHORT).show();
            }
            else {
                ActivityCompat.requestPermissions(Register.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PReqCode);


            }


        }
        else

            openGallery();


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUESTCODE && data != null){
            //der nutzer hat erfolgreich ein image ausgewählt
            //wir müssen die Referenz abspeichern!
            pickedImgUri = data.getData();
            img.setImageURI(pickedImgUri);

        }
    }


}