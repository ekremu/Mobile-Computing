package com.example.prime.test3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import android.widget.Button;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.prime.test3.model.Profile;
import com.example.prime.test3.viewmodel.ProfileViewModel;

import org.w3c.dom.Text;

import java.util.List;

public class Register extends AppCompatActivity {


    private ProfileViewModel viewModel;

    ImageView img;
    static int PReqCode = 1;
    static int REQUESTCODE = 1;
    Uri pickedImgUri;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        img = findViewById(R.id.img_photoAdd);
        viewModel = ViewModelProviders.of(this).get(ProfileViewModel.class);
        setScore(0);
        setupButton();


        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT >= 22){

                    requestForPermission();

                }

                else
                {
                    openGallery();
                }




            }
        });

    }

    private void setupButton(){
        Button buttonAdd = findViewById(R.id.btn_registersignin);
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            //    viewModel.addProfile(findViewById(R.id.txt_username),findViewById(R.id.txt_email),findViewById(R.id.txt_password),findViewById(R.id.txt_stadt),findViewById(R.id.txt_score));
                viewModel.addProfile("asdf","email","1234","gummersbach",0);
            }
        });
    }

    private void displayAllInformations(){

        viewModel.getProfiles().observe(this, new Observer<List<Profile>>() {
            @Override
            public void onChanged(List<Profile> profiles) {
                renderAllProfiles(profiles);
            }
        });

    }

    private void renderAllProfiles(List<Profile> profiles) {
        LinearLayout container = findViewById(R.id.ll_container);
        container.removeAllViews();
        for (Profile p: profiles){
            container.addView((View) getProfileTextView(p));
            //container.addView getProfileTextView(p));
        }

    }

    private Text getProfileTextView(Profile p){

        TextView textView = new TextView(Register.this);
        textView.setText(p.getNickname() + "(" + p.getEmail() + p.getStadt() + p.getScore() + ")\n");
        return (Text) textView;

    }



    //image hinzufügen

    private void openGallery() {

        Intent galleryIntent  = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,REQUESTCODE);

    }

    private void requestForPermission() {

        if (ContextCompat.checkSelfPermission(Register.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(Register.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

                Toast.makeText(Register.this, "Please accept for required Permissions", Toast.LENGTH_SHORT).show();
            }
            else {
                ActivityCompat.requestPermissions(Register.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PReqCode);


            }


        }
        else

            openGallery();


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUESTCODE && data != null){
            //der nutzer hat erfolgreich ein image ausgewählt
            //wir müssen die Referenz abspeichern!
            pickedImgUri = data.getData();
            img.setImageURI(pickedImgUri);

        }
    }

    public void setScore(int score) {
        this.score = score;
    }
}