//Das Modell enthält Daten, die von der Präsentation dargestellt werden. Es ist von Präsentation
// und Steuerung unabhängig. Die Änderungen der Daten werden der Präsentation durch das Entwurfsmuster
// „Beobachter“ bekanntgegeben. In manchen Umsetzungen des MVC-Musters enthält das Modell eine Geschäftslogik,
// die für die Änderung der Daten zuständig ist.
package com.example.prime.test3.model;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;


public class ProfileStore {

    private List<Profile> profileList = new ArrayList<>();
    private MutableLiveData<List<Profile>> profiles = new MutableLiveData<>();


    public void addProfile(Profile profile){

        profileList.add(profile);
        profiles.postValue(profileList);

    }

    public LiveData<List<Profile>> getAllProfiles(){
        return profiles;
    }

}
