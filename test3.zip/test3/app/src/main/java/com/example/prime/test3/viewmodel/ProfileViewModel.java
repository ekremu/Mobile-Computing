//ViewModel: Enthält die UI-Logik (Model der View) und dient als Bindeglied zwischen View und obigem Model.
// Einerseits tauscht es Information mit dem Model aus, ruft also Methoden oder Dienste auf. Andererseits stellt es der
// View öffentliche Eigenschaften und Befehle zur Verfügung. Diese werden von der View an Steuerelemente gebunden,
// um Inhalte auszugeben bzw. UI-Ereignisse weiterzuleiten. Das ViewModel darf dabei keinerlei Kenntnis der View besitzen.

package com.example.prime.test3.viewmodel;

import android.view.View;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import com.example.prime.test3.model.Profile;
import com.example.prime.test3.model.ProfileStore;

public class ProfileViewModel extends ViewModel {

    private ProfileStore profileS;

    public ProfileViewModel(){
        this.profileS = new ProfileStore();
    }

    public LiveData<List<Profile>> getProfiles(){
        return profileS.getAllProfiles();
    }

    /*
    public void addProfile(View nickname, View email, View password, View stadt, View score){
    profileS.addProfile(new Profile(nickname,email,password,stadt,score));
    }


     */
    public void addProfile(String nickname, String email, String password, String stadt, int score){
        profileS.addProfile(new Profile(nickname,email,password,stadt, score));
    }



}
